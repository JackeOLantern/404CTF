import re
import zlib

pdf = open("super_secret2.pdf", "rb").read()
stream = re.compile(rb'.*?FlateDecode.*?stream(.*?)endstream', re.S)
i = 0
for s in stream.findall(pdf):
    s = s.strip(b'\r\n').strip(b'\n')
    i =  i + 1
    #print(s)
    #try:
    data = zlib.decompress(s)
    with open("out"+str(i)+".bin", 'wb') as f:
        f.write(data)

    #except:
    #    pass