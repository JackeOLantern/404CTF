import numpy
import zlib
data = b''
with open("stream1.bin", 'rb') as zFile:
    for line in zFile:
        data = data + line.strip()
    print(data)
    decompressed = zlib.decompress(data)
    with open("stream1_a.bin", 'rb') as f:
        f.write(decompressed)
