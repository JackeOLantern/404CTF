
from base64 import encode
import binascii
fileHex = ['666c61672e747874', '68616c6c6562617264652e706e67', '73757065722d7365637265742e706466', '657866696c74726174696f6e2e7079']
resu = []

for f in fileHex:
    # binascii.hexlify(filename.encode()).decode()
    fileHex2 = binascii.unhexlify(f.encode()).decode()
    resu.append(fileHex2)

print(sorted(resu))
flag = ''#
for f in sorted(resu):
    if (len(flag) > 0):
        flag = flag + ','
    flag = flag + f
flag = '404CTF{' + flag + '}'
print(flag)

# step 3/3
print(resu)

flagData = ['3430344354467b706173206c6520666c', '61672c20646f6d6d616765203a707d0a']
flagResu = []
for f in flagData:
    fileHex2 = binascii.unhexlify(f.encode()).decode()
    flagResu.append(fileHex2)
print(flagResu)

'''
with open('data4_clean.txt', "r") as file4:
    file4Resu = []
    lines4 = file4.readlines()
    for l in lines4:
        ls = l.strip()
        print(ls)
        fileHex2 = binascii.unhexlify(ls.encode()).decode()
        file4Resu.append(fileHex2)
    print(file4Resu)
'''
with open('super_secret2.pdf', "wb") as f4:
    with open('data3_clean.txt', "r") as file4:
        file4Resu = []
        lines4 = file4.readlines()
        for l in lines4:
            ls = l.strip()
            bin =  binascii.unhexlify(ls.encode())
            #print(ls, "=>", bin)
            #fileHex2 = bin.decode('ascii', errors='replace')
            #file4Resu.append(fileHex2)
            f4.write(bin)
'''
with open('hallebarde.png', "wb") as f4:
    with open('data2_clean.txt', "r") as file4:
        file4Resu = []
        lines4 = file4.readlines()
        for l in lines4:
            ls = l.strip()
            bin =  binascii.unhexlify(ls.encode())
            #print(ls, "=>", bin)
            #fileHex2 = bin.decode(errors='replace')
            #file4Resu.append(fileHex2)
            f4.write(bin)
'''